/* global QUnit */

// import { ImageUtils } from '../../../../src/extras/ImageUtils.js';

export default QUnit.module( 'Extras', () => {

	QUnit.module( 'ImageUtils', () => {

		// STATIC
		QUnit.todo( 'getDataURL', ( assert ) => {

			assert.ok( false, 'everything\'s gonna be alright' );

		} );

		QUnit.todo( 'sRGBToLinear', ( assert ) => {

			assert.ok( false, 'everything\'s gonna be alright' );

		} );

	} );

} );
