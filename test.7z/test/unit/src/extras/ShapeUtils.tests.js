/* global QUnit */

// import { ShapeUtils } from '../../../../src/extras/ShapeUtils.js';

export default QUnit.module( 'Extras', () => {

	QUnit.module( 'ShapeUtils', () => {

		// STATIC
		QUnit.todo( 'area', ( assert ) => {

			assert.ok( false, 'everything\'s gonna be alright' );

		} );

		QUnit.todo( 'isClockWise', ( assert ) => {

			assert.ok( false, 'everything\'s gonna be alright' );

		} );

		QUnit.todo( 'triangulateShape', ( assert ) => {

			assert.ok( false, 'everything\'s gonna be alright' );

		} );

	} );

} );
