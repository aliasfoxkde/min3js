/* global QUnit */

// import { Earcut } from '../../../../src/extras/Earcut.js';

export default QUnit.module( 'Extras', () => {

	QUnit.module( 'Earcut', () => {

		// Public
		QUnit.todo( 'triangulate', ( assert ) => {

			assert.ok( false, 'everything\'s gonna be alright' );

		} );

	} );

} );
