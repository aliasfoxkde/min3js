export default /* glsl */`
#ifdef USE_FOG

	vFogDepth = - mvPosition.z;

#endif
`;
