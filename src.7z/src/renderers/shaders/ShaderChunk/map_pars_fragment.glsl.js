export default /* glsl */`
#ifdef USE_MAP

	uniform sampler2D map;

#endif
`;
